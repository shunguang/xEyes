/****************************************************************************
** Meta object code from reading C++ file 'RunGui.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../libRun/RunGui.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'RunGui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_xeyes__RunGui_t {
    QByteArrayData data[26];
    char stringdata0[586];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_xeyes__RunGui_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_xeyes__RunGui_t qt_meta_stringdata_xeyes__RunGui = {
    {
QT_MOC_LITERAL(0, 0, 13), // "xeyes::RunGui"
QT_MOC_LITERAL(1, 14, 23), // "on_actionExit_triggered"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 10), // "closeEvent"
QT_MOC_LITERAL(4, 50, 12), // "QCloseEvent*"
QT_MOC_LITERAL(5, 63, 5), // "event"
QT_MOC_LITERAL(6, 69, 23), // "on_actionHelp_triggered"
QT_MOC_LITERAL(7, 93, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(8, 118, 36), // "on_actionDecreaseDispImgSz_tr..."
QT_MOC_LITERAL(9, 155, 31), // "on_pushButton_startExit_clicked"
QT_MOC_LITERAL(10, 187, 42), // "on_comboBoxDspCamImgSz_curren..."
QT_MOC_LITERAL(11, 230, 3), // "idx"
QT_MOC_LITERAL(12, 234, 29), // "on_checkBox_camRec0_stateChgd"
QT_MOC_LITERAL(13, 264, 5), // "state"
QT_MOC_LITERAL(14, 270, 29), // "on_checkBox_camRec1_stateChgd"
QT_MOC_LITERAL(15, 300, 29), // "on_checkBox_camRec2_stateChgd"
QT_MOC_LITERAL(16, 330, 29), // "on_checkBox_camRec3_stateChgd"
QT_MOC_LITERAL(17, 360, 27), // "on_checkBox_disp0_stateChgd"
QT_MOC_LITERAL(18, 388, 27), // "on_checkBox_disp1_stateChgd"
QT_MOC_LITERAL(19, 416, 27), // "on_checkBox_disp2_stateChgd"
QT_MOC_LITERAL(20, 444, 27), // "on_checkBox_disp3_stateChgd"
QT_MOC_LITERAL(21, 472, 27), // "on_lineEdit_camName0_edited"
QT_MOC_LITERAL(22, 500, 1), // "s"
QT_MOC_LITERAL(23, 502, 27), // "on_lineEdit_camName1_edited"
QT_MOC_LITERAL(24, 530, 27), // "on_lineEdit_camName2_edited"
QT_MOC_LITERAL(25, 558, 27) // "on_lineEdit_camName3_edited"

    },
    "xeyes::RunGui\0on_actionExit_triggered\0"
    "\0closeEvent\0QCloseEvent*\0event\0"
    "on_actionHelp_triggered\0"
    "on_actionAbout_triggered\0"
    "on_actionDecreaseDispImgSz_triggered\0"
    "on_pushButton_startExit_clicked\0"
    "on_comboBoxDspCamImgSz_currentIndexChanged\0"
    "idx\0on_checkBox_camRec0_stateChgd\0"
    "state\0on_checkBox_camRec1_stateChgd\0"
    "on_checkBox_camRec2_stateChgd\0"
    "on_checkBox_camRec3_stateChgd\0"
    "on_checkBox_disp0_stateChgd\0"
    "on_checkBox_disp1_stateChgd\0"
    "on_checkBox_disp2_stateChgd\0"
    "on_checkBox_disp3_stateChgd\0"
    "on_lineEdit_camName0_edited\0s\0"
    "on_lineEdit_camName1_edited\0"
    "on_lineEdit_camName2_edited\0"
    "on_lineEdit_camName3_edited"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_xeyes__RunGui[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x09 /* Protected */,
       3,    1,  110,    2, 0x09 /* Protected */,
       6,    0,  113,    2, 0x09 /* Protected */,
       7,    0,  114,    2, 0x09 /* Protected */,
       8,    0,  115,    2, 0x09 /* Protected */,
       9,    0,  116,    2, 0x09 /* Protected */,
      10,    1,  117,    2, 0x09 /* Protected */,
      12,    1,  120,    2, 0x09 /* Protected */,
      14,    1,  123,    2, 0x09 /* Protected */,
      15,    1,  126,    2, 0x09 /* Protected */,
      16,    1,  129,    2, 0x09 /* Protected */,
      17,    1,  132,    2, 0x09 /* Protected */,
      18,    1,  135,    2, 0x09 /* Protected */,
      19,    1,  138,    2, 0x09 /* Protected */,
      20,    1,  141,    2, 0x09 /* Protected */,
      21,    1,  144,    2, 0x09 /* Protected */,
      23,    1,  147,    2, 0x09 /* Protected */,
      24,    1,  150,    2, 0x09 /* Protected */,
      25,    1,  153,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString,   22,

       0        // eod
};

void xeyes::RunGui::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RunGui *_t = static_cast<RunGui *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actionExit_triggered(); break;
        case 1: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 2: _t->on_actionHelp_triggered(); break;
        case 3: _t->on_actionAbout_triggered(); break;
        case 4: _t->on_actionDecreaseDispImgSz_triggered(); break;
        case 5: _t->on_pushButton_startExit_clicked(); break;
        case 6: _t->on_comboBoxDspCamImgSz_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_checkBox_camRec0_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_checkBox_camRec1_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_checkBox_camRec2_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_checkBox_camRec3_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_checkBox_disp0_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_checkBox_disp1_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_checkBox_disp2_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_checkBox_disp3_stateChgd((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_lineEdit_camName0_edited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->on_lineEdit_camName1_edited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->on_lineEdit_camName2_edited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: _t->on_lineEdit_camName3_edited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject xeyes::RunGui::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_xeyes__RunGui.data,
      qt_meta_data_xeyes__RunGui,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *xeyes::RunGui::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *xeyes::RunGui::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_xeyes__RunGui.stringdata0))
        return static_cast<void*>(const_cast< RunGui*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int xeyes::RunGui::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
