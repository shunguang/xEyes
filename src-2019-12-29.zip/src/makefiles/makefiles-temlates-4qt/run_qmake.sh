/home/wus1/pkg/qt_5_9_install/bin/qmake -makefile runApps_qmake.pro

