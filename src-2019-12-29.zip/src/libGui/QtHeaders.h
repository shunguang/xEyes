/**
* @file   UtilDefs.h
* @author Shunguang@yahoo.com
* @date   Feb 05, 2017
*
*------------------------------------------------------------------------------
**/

#ifndef __QT_HEADERS_H__
#define __QT_HEADERS_H__

#include <QtCore/QtCore>
#include <QtGui/QtGui>
#include <QtCore/QTimer>
#include <QtCore/QString>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QApplication>
#include <QtGui/QCloseEvent>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QFileDialog>

#endif

